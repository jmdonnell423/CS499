// File: InventoryItem.kt
package com.main.project3

data class InventoryItem(val name: String, var quantity: Int)





