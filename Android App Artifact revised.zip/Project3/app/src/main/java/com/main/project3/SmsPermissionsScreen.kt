package com.main.project3

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.main.project3.ui.theme.Project3Theme

@Composable
fun SmsPermissionScreen(
    modifier: Modifier = Modifier,
    onPermissionGranted: () -> Unit = {}
) {
    val context = LocalContext.current as ComponentActivity
    val viewModel: SmsPermissionViewModel = viewModel()
    val hasPermission by viewModel.hasPermission.collectAsState()

    LaunchedEffect(key1 = Unit) {
        val isGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED
        viewModel.updatePermissionStatus(isGranted)

        if (isGranted) {
            onPermissionGranted()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center
    ) {
        if (hasPermission) {
            Text("SMS Permission Granted")
        } else {
            Button(onClick = {
                ActivityCompat.requestPermissions(
                    context,
                    arrayOf(Manifest.permission.SEND_SMS),
                    SmsPermissionViewModel.REQUEST_SMS_PERMISSION
                )
            }) {
                Text("Request SMS Permission")
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun SmsPermissionScreenPreview() {
    Project3Theme {
        SmsPermissionScreen()
    }
}







