// File: InventoryScreen.kt
package com.main.project3

import android.content.ContentValues
import android.content.Context
import android.telephony.SmsManager
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.tooling.preview.Preview
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import com.main.project3.ui.theme.Project3Theme

@Composable
fun InventoryScreen(modifier: Modifier = Modifier, onLogout: () -> Unit = {}) {
    val context = LocalContext.current
    val dbHelper = remember { DatabaseHelper(context) }
    val items = remember { mutableStateListOf<InventoryItem>() }
    var searchQuery by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        // Load inventory items from the database
        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM inventory", null)
        while (cursor.moveToNext()) {
            val name = cursor.getString(cursor.getColumnIndexOrThrow("name"))
            val quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"))
            items.add(InventoryItem(name, quantity))
        }
        cursor.close()
        db.close()
    }

    var showDialog by remember { mutableStateOf(false) }

    Column(modifier = modifier.fillMaxSize().padding(16.dp)) {
        // Top row with buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Button(onClick = { showDialog = true }) {
                Text("Add Item")
            }
            Button(onClick = { onLogout() }) {
                Text("Logout")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Search bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("Search by name") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Filtered list of items
        val filteredItems = items.filter {
            it.name.contains(searchQuery, ignoreCase = true)
        }

        LazyColumn {
            items(filteredItems) { item ->
                InventoryItemRow(
                    item = item,
                    onDelete = {
                        // Delete item from database and list
                        val db = dbHelper.writableDatabase
                        db.delete("inventory", "name=?", arrayOf(item.name))
                        db.close()
                        items.remove(item)
                    },
                    onQuantityChange = { newQuantity ->
                        item.quantity = newQuantity
                        // Update item in database
                        val db = dbHelper.writableDatabase
                        val contentValues = ContentValues().apply {
                            put("quantity", newQuantity)
                        }
                        db.update("inventory", contentValues, "name=?", arrayOf(item.name))
                        db.close()
                        // Send SMS if the quantity drops below 3
                        if (newQuantity < 3) {
                            sendSms(context, "5556", "Alert: Inventory for ${item.name} is low. Only $newQuantity left.")
                        }
                    }
                )
            }
        }
    }

    if (showDialog) {
        AddItemDialog(
            onAddItem = { newItem ->
                // Add new item to the database and list
                val db = dbHelper.writableDatabase
                val contentValues = ContentValues().apply {
                    put("name", newItem.name)
                    put("quantity", newItem.quantity)
                }
                db.insert("inventory", null, contentValues)
                db.close()
                items.add(newItem)
                showDialog = false
            },
            onDismiss = { showDialog = false }
        )
    }
}


@Composable
fun InventoryItemRow(item: InventoryItem, onDelete: () -> Unit, onQuantityChange: (Int) -> Unit) {
    var quantity by remember { mutableIntStateOf(item.quantity) }
    var isUpdated by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(text = item.name)
            Row {
                Text(text = "Quantity: ")
                OutlinedTextField(
                    value = quantity.toString(),
                    onValueChange = {
                        val newQuantity = it.toIntOrNull() ?: 0
                        quantity = newQuantity
                        isUpdated = newQuantity != item.quantity
                    },
                    modifier = Modifier.width(60.dp),
                    keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        onQuantityChange(quantity)
                        isUpdated = false
                    },
                    enabled = isUpdated
                ) {
                    Text("Update")
                }
            }
        }
        Button(onClick = onDelete) {
            Text("Delete")
        }
    }
}

fun sendSms(context: Context, phoneNumber: String, message: String) {
    // Use application context to ensure the service is correctly accessed
    val appContext = context.applicationContext
    val smsManager = ContextCompat.getSystemService(appContext, SmsManager::class.java)

    if (smsManager != null) {
        val permissionCheck = ContextCompat.checkSelfPermission(appContext, android.Manifest.permission.SEND_SMS)

        if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
            smsManager.sendTextMessage(phoneNumber, null, message, null, null)
            Log.d("SMS", "SMS sent to $phoneNumber: $message")
            // Show a toast message confirming the SMS was sent
            Toast.makeText(appContext, "SMS sent to $phoneNumber", Toast.LENGTH_SHORT).show()
        } else {
            ActivityCompat.requestPermissions(
                context as ComponentActivity,
                arrayOf(android.Manifest.permission.SEND_SMS),
                SmsPermissionViewModel.REQUEST_SMS_PERMISSION
            )
        }
    } else {
        Log.e("SMS", "SmsManager is null, cannot send SMS")
        Toast.makeText(appContext, "Failed to send SMS", Toast.LENGTH_SHORT).show()
    }
}


@Composable
fun AddItemDialog(onAddItem: (InventoryItem) -> Unit, onDismiss: () -> Unit) {
    var newItemName by remember { mutableStateOf("") }
    var newItemQuantity by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add New Item") },
        text = {
            Column {
                OutlinedTextField(
                    value = newItemName,
                    onValueChange = { newItemName = it },
                    label = { Text("Item Name") }
                )
                OutlinedTextField(
                    value = newItemQuantity,
                    onValueChange = { newItemQuantity = it },
                    label = { Text("Quantity") },
                    keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (newItemName.isNotBlank() && newItemQuantity.isNotBlank()) {
                        val quantity = newItemQuantity.toIntOrNull() ?: 0
                        onAddItem(InventoryItem(newItemName, quantity))
                    }
                }
            ) {
                Text("Add")
            }
        },
        dismissButton = {
            Button(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Preview(showBackground = true)
@Composable
fun InventoryScreenPreview() {
    Project3Theme {
        InventoryScreen()
    }
}











