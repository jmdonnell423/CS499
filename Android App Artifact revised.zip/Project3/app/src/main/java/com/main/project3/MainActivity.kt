// File: MainActivity.kt
package com.main.project3

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.main.project3.ui.theme.Project3Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Project3Theme {
                val loggedIn = remember { mutableStateOf(false) }
                val hasSmsPermission = remember { mutableStateOf(false) }

                // Check if SMS permission is granted
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                    hasSmsPermission.value = true
                }

                if (!hasSmsPermission.value) {
                    SmsPermissionScreen(onPermissionGranted = { hasSmsPermission.value = true })
                } else if (loggedIn.value) {
                    InventoryScreen(
                        modifier = Modifier.fillMaxSize(),
                        onLogout = { loggedIn.value = false }
                    )
                } else {
                    LoginScreen(
                        modifier = Modifier.fillMaxSize(),
                        onLoginSuccess = { loggedIn.value = true }
                    )
                }
            }
        }

        // Register the permissions result callback
        val requestPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
            if (isGranted) {
                recreate()
            }
        }

        // Request SMS permission if not granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissionLauncher.launch(Manifest.permission.SEND_SMS)
        }
    }
}














