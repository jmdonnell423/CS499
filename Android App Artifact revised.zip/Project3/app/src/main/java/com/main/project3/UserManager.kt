// File: UserManager.kt
package com.main.project3

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.content.ContentValues

class UserManager(context: Context) {

    private val dbHelper = DatabaseHelper(context)

    fun createUser(username: String, password: String): Boolean {
        val db = dbHelper.writableDatabase
        val contentValues = ContentValues().apply {
            put("username", username)
            put("password", password)
        }
        val newRowId = db.insert("users", null, contentValues)
        db.close()
        return newRowId != -1L
    }

    fun validateUser(username: String, password: String): Boolean {
        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM users WHERE username = ? AND password = ?", arrayOf(username, password))
        val isValid = cursor.count > 0
        cursor.close()
        db.close()
        return isValid
    }
}


