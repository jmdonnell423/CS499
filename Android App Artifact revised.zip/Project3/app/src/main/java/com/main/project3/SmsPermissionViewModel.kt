package com.main.project3

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class SmsPermissionViewModel : ViewModel() {

    companion object {
        const val REQUEST_SMS_PERMISSION = 1
    }

    private val _hasPermission = MutableStateFlow(false)
    val hasPermission: StateFlow<Boolean> = _hasPermission

    fun updatePermissionStatus(granted: Boolean) {
        _hasPermission.value = granted
    }
}




