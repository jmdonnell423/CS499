// File: LoginScreen.kt
package com.main.project3

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.ui.platform.LocalContext
import com.main.project3.ui.theme.Project3Theme
import androidx.compose.ui.Alignment


@Composable
fun LoginScreen(modifier: Modifier = Modifier, onLoginSuccess: () -> Unit = {}) {
    val context = LocalContext.current
    val userManager = remember { UserManager(context) }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var showCreateAccount by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center
    ) {
        // Add Title
        Text(
            text = if (showCreateAccount) "Create Account" else "Welcome to Inventory Manager",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .padding(bottom = 24.dp) // Spacing below the title
        )

        // Username Field
        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Username") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        // Password Field
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            modifier = Modifier.fillMaxWidth(),
            visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
            singleLine = true,
            trailingIcon = {
                val icon = if (showPassword) Icons.Filled.Visibility else Icons.Filled.VisibilityOff
                IconButton(onClick = { showPassword = !showPassword }) {
                    Icon(imageVector = icon, contentDescription = null)
                }
            },
            keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Password)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Login/Create Account Button
        Button(
            onClick = {
                if (username.isBlank() || password.isBlank()) {
                    errorMessage = "Username and password cannot be empty."
                    return@Button
                }
                if (password.length < 8) {
                    errorMessage = "Password must be at least 8 characters long."
                    return@Button
                }
                if (showCreateAccount) {
                    val created = userManager.createUser(username, password)
                    if (created) {
                        Toast.makeText(context, "Account created successfully!", Toast.LENGTH_SHORT).show()
                        onLoginSuccess()
                    } else {
                        errorMessage = "Account creation failed. User already exists."
                    }
                } else {
                    val valid = userManager.validateUser(username, password)
                    if (valid) {
                        Toast.makeText(context, "Login successful!", Toast.LENGTH_SHORT).show()
                        onLoginSuccess()
                    } else {
                        errorMessage = "Invalid username or password."
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (showCreateAccount) "Create Account" else "Login")
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Toggle Login/Create Account
        TextButton(
            onClick = { showCreateAccount = !showCreateAccount },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (showCreateAccount) "Back to Login" else "Create Account")
        }

        // Error Message
        if (errorMessage.isNotBlank()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = errorMessage, color = MaterialTheme.colorScheme.error)
        }
    }
}



@Preview(showBackground = true)
@Composable
fun LoginScreenPreview() {
    Project3Theme {
        LoginScreen()
    }
}








