#include <iostream>
#include <limits>
#include <unordered_map>
#include <string>

// Simulated user authentication
std::unordered_map<std::string, std::string> userDatabase = {
    {"user1", "password123"},
    {"admin", "securePass"},
    {"guest", "guestPass"}
};

bool AuthenticateUser(const std::string& username, const std::string& password) {
    auto it = userDatabase.find(username);
    if (it == userDatabase.end()) {
        std::cout << "Error: Username does not exist.\n";
        return false;
    }
    if (it->second != password) {
        std::cout << "Error: Incorrect password.\n";
        return false;
    }
    std::cout << "Login successful!\n";
    return true;
}

// Function to safely get user choice with validation
int GetValidatedChoice() {
    int choice;
    while (true) {
        std::cout << "Enter your choice (1-5): ";
        if (std::cin >> choice) {
            if (choice >= 1 && choice <= 5) {
                return choice;
            }
            std::cout << "Invalid choice. Please select a number between 1 and 5.\n";
        } else {
            std::cout << "Invalid input. Please enter a number.\n";
            std::cin.clear();  // Clear error flags
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');  // Discard invalid input
        }
    }
}

// Main function
int main() {
    std::string username, password;
    std::cout << "Enter username: ";
    std::cin >> username;
    std::cout << "Enter password: ";
    std::cin >> password;

    if (!AuthenticateUser(username, password)) {
        return 1;  // Exit if authentication fails
    }

    // Get a valid user choice
    int userChoice = GetValidatedChoice();
    std::cout << "You selected option " << userChoice << "." << std::endl;
    std::cout << "Created by Joshua Donnelly." << std::endl;
    return 0;
}

